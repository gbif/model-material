

-- see gum_setup.sql for howto/copypasta
-- this gets executed as a text file, so
-- maybe-kinda-somehow could be run by cron or cfscheduler

truncate table gum.collection;
truncate table gum.agent_group;
truncate table gum.agent_relationship;
truncate table gum.agent;
truncate table gum.collection;
truncate table gum.agent_group;
truncate table gum.agent_relationship;
truncate table gum.reference;
truncate table gum.digital_entity;
truncate table gum.entity_relationship;
truncate table gum.occurrence;
truncate table  gum.organism;
truncate table gum.taxon_identification;
truncate table gum.taxon;
truncate table gum.identification;
truncate table gum.chronometric_age;
truncate table gum."assertion";
truncate table gum.identifier;
truncate table gum.agent_role;
truncate table gum.event;
truncate table gum.material_entity;
truncate table gum.entity;
truncate table gum.protocol;
truncate table gum.georeference;
truncate table gum.geological_context;
truncate table gum.location;






--- add these in here, they get stripped for export
--- not strictly necessary but they make things faster
--- and reduce the chances of me borking something



alter table gum.identification add arctos_IID int;
alter table gum.identification add arctos_AIID int;
alter table gum.entity  add arctos_CID int;
alter table gum.entity  add arctos_PID int;
alter table gum.entity  add arctos_MID int;
create index gum_ent_cid on gum.entity (arctos_CID);
create index gum_ent_pid on gum.entity (arctos_PID);
create index gum_ent_mid on gum.entity (arctos_MID);
alter table gum.location add arctos_LID int;
create index ix_gumlocationarctos_LID on gum.location (arctos_LID);
alter table gum.event add arctos_EID int;
alter table gum.event add arctos_SEID int;



-------------------------------------- now insert for export




insert into gum.agent (
 agent_id,
 agent_type,
 preferred_agent_name
) (
select
 concat('https://arctos.database.museum/agent/',agent_id::text),
 agent_type,
 preferred_agent_name
from
 agent
);


--- now department of reundancy department in collectionIDs as agents
--  but we'll make relationships later, this shouldn't be disruptive!


insert into gum.agent (
 agent_id,
 agent_type,
 preferred_agent_name
) (
select
 concat('https://arctos.database.museum/collection/',guid_prefix),
 'collection',
 concat('https://arctos.database.museum/collection/',guid_prefix)
from
 collection
);


insert into gum.collection (
collection_id,
collection_type,
collection_code,
institution_code,
grscicoll_id
  )(
select
 concat('https://arctos.database.museum/collection/',guid_prefix),
 collection, -- wut??
 collection_cde, -- guessing this isn't right but ???
 institution_acronym, -- ??
 graddy.grscicoll_id
 from collection
 left outer join (
  -- bah!! this wants a UUID!!! EVIL!!!!!
  select string_agg(replace(gra.address,'https://registry.gbif.org/collection/',''),'|')::UUID as grscicoll_id ,cid.address
  from address gra
  inner join address cid on cid.agent_id=gra.agent_id
  where gra.address_type='url' and gra.address ilike 'https://registry.gbif.org/collection/%' and cid.address_type='collectionID'
  group by gra.address,cid.address
  ) graddy on graddy.address= concat('https://arctos.database.museum/collection/',guid_prefix)
);




-- this is overly simplified, can't do on-and-off relationships, need unique
-- delete from  gum.agent_relationship

insert into gum.agent_relationship  (
    subject_agent_id,
    relationship_to,
    object_agent_id
) (
    select
        concat('https://arctos.database.museum/agent/',agent_id::text),
        agent_relationship,
        concat('https://arctos.database.museum/agent/',related_agent_id::text)
    from agent_relations
    group by agent_id,agent_relationship,related_agent_id
);

-- hook up my two agent/collection/agent/thingee/agents
-- but these don't all exist so actually join I guess

insert into gum.agent_relationship  (
    subject_agent_id,
    relationship_to,
    object_agent_id
) (
    select
        concat('https://arctos.database.museum/agent/',address.agent_id::text),
        'same as',
        address
    from address
    inner join gum.agent sa on sa.agent_id=concat('https://arctos.database.museum/agent/',address.agent_id::text)
    inner join gum.agent oa on oa.agent_id=address.address
     where address.address_type='collectionID'
);




insert into gum.reference (
    reference_id,
    reference_type,
    bibliographic_citation,
    reference_year,
    reference_iri,
    is_peer_reviewed
) (select
     concat('https://arctos.database.museum/publication/',publication_id::text),
     publication_type,
     full_citation,
     published_year,
     doi,
     case when is_peer_reviewed_fg=0 then false else true end
    from publication
    where published_year BETWEEN 1600 AND 2022
);








-- flush delete from gum.entity where entity_type='MATERIAL_ENTITY' and arctos_CID is not null and arctos_PID is null
-- cataloged items
insert into gum.entity (
  entity_id,
  entity_type,
  dataset_id,
  entity_name,
  entity_remarks,
  arctos_CID
) (
select
 concat('https://arctos.database.museum/guid/',guid_prefix,':',cat_num),
 'MATERIAL_ENTITY', -- cataloged items are definitely not material anything
 --- tuco says "entity.entity_type MUST be 'MATERIAL_ENTITY' for Organism parent entities,"
 concat('https://arctos.database.museum/collection/',guid_prefix),
 null, -- what the heck is this?
 case when msr.encumbrance_id is null then coll_object_remark.coll_object_remarks else null end,
 cataloged_item.collection_object_id
 from cataloged_item
 inner join collection on cataloged_item.collection_id=collection.collection_id
 left outer join coll_object_remark on cataloged_item.collection_object_id=coll_object_remark.collection_object_id
 -- avoid mask record encumbrances entirely
 left outer join (
    select coll_object_encumbrance.collection_object_id,encumbrance.encumbrance_id
    from encumbrance inner join coll_object_encumbrance on coll_object_encumbrance.encumbrance_id=encumbrance.encumbrance_id and
    encumbrance_action='mask record'
) mre on cataloged_item.collection_object_id=mre.collection_object_id
 -- filter on mask remarks
 left outer join (
    select coll_object_encumbrance.collection_object_id,encumbrance.encumbrance_id
    from encumbrance inner join coll_object_encumbrance on coll_object_encumbrance.encumbrance_id=encumbrance.encumbrance_id and
    encumbrance_action='mask specimen remarks'
) msr on cataloged_item.collection_object_id=msr.collection_object_id
where mre.encumbrance_id is null
--- by JRW request: unhugeify this
-- from MLC: Use MSB:Host--
and collection.guid_prefix in ('MSB:Host','MSB:Para')
);

-- cataloged items
-- avoid encumbrances by joining to entity
--This thing "https://arctos.database.museum/guid/DMNS:Mamm:11098" also had an internal collection_object_id that was used for glue in the csvs. And that thing was a MaterialEntity of the type dwc:Organism.

insert into gum.material_entity (
  material_entity_id,
  material_entity_type,
  preparations ,
  disposition,
  institution_code,
  institution_id,
  collection_code,
  collection_id,
  owner_institution_code,
  catalog_number,
  record_number,
  recorded_by,
  recorded_by_id,
  associated_references,
  associated_sequences,
  other_catalog_numbers
) (
select
     concat('https://arctos.database.museum/guid/',guid_prefix,':',cat_num),
     'ORGANISM', -- not really but sorta-sometimes-maybe
     null,
     null,
     institution_acronym, -- ???????????
     institution_acronym, -- even more emphatic state of confusion
     collection_cde, -- don't think this is what GBIF thinks it is...
     concat('https://arctos.database.museum/collection/',guid_prefix),
     institution_acronym, -- ???????????
     cat_num,
     null, -- wut??
     null,
     null,
     null,
     null,
     null
from cataloged_item
 inner join collection on cataloged_item.collection_id=collection.collection_id
 inner join gum.entity on cataloged_item.collection_object_id=gum.entity.arctos_CID
 where gum.entity.arctos_PID is null and gum.entity.arctos_mid is null

);



-- now parts
-- no encumbrances seem to apply to this, but join to  gum.entity to avoid mask record encumbrances
insert into gum.entity (
  entity_id,
  entity_type,
  dataset_id,
  entity_name,
  entity_remarks,
  arctos_PID,
  arctos_CID
) (
select
 concat('https://arctos.database.museum/guid/',guid_prefix,':',cat_num,'/PID',specimen_part.collection_object_id),
 'MATERIAL_ENTITY',
 concat('https://arctos.database.museum/collection/',guid_prefix), -- not sure what this should be here, maybe the catalog record?????
 null, -- what the heck is this?
 null, -- and this? catrec remark???? If so add but watch encumbrances
 specimen_part.collection_object_id,
 specimen_part.derived_from_cat_item
 from cataloged_item
 inner join specimen_part on cataloged_item.collection_object_id=specimen_part.derived_from_cat_item
 inner join gum.entity on cataloged_item.collection_object_id=gum.entity.arctos_CID and gum.entity.arctos_PID is null and gum.entity.arctos_mid is null
 inner join collection on cataloged_item.collection_id=collection.collection_id
);



-- parts again for some reason

insert into gum.material_entity (
  material_entity_id,
  material_entity_type,
  preparations ,
  disposition,
  institution_code,
  institution_id,
  collection_code,
  collection_id,
  owner_institution_code,
  catalog_number,
  record_number,
  recorded_by,
  recorded_by_id,
  associated_references,
  associated_sequences,
  other_catalog_numbers
) (
select
     concat('https://arctos.database.museum/guid/',guid_prefix,':',cat_num,'/PID',specimen_part.collection_object_id),
     'part', --- whut??
     part_name,
     coll_obj_disposition,
     institution_acronym, -- ???????????
     institution_acronym, -- even more emphatic state of confusion - and why is this replicated here????
     collection_cde, -- don't think this is what GBIF thinks it is...
     concat('https://arctos.database.museum/collection/',guid_prefix),
     institution_acronym, -- ???????????
     cat_num,
     null, -- wut??
     null,
     null,
     null,
     null,
     null
from cataloged_item
 inner join specimen_part on cataloged_item.collection_object_id=specimen_part.derived_from_cat_item
 inner join coll_object on specimen_part.collection_object_id=coll_object.collection_object_id
 inner join collection on cataloged_item.collection_id=collection.collection_id
 inner join gum.entity on cataloged_item.collection_object_id=gum.entity.arctos_CID and gum.entity.arctos_PID is null and gum.entity.arctos_mid is null
);




-- where to put part attribtues??
-- assertion, that's where, down yonder!


-- media
-- no filters here
insert into gum.entity (
  entity_id,
  entity_type,
  dataset_id,
  entity_name,
  entity_remarks,
  arctos_MID
) (
select
 concat('https://arctos.database.museum/media/',media.media_id),
 'DIGITAL_ENTITY',
 'https://arctos.database.museum', -- https://github.com/gbif/model-material/issues/110
 null, -- what the heck is this?
 null, -- and this?
 media.media_id
 from media
);



insert into gum.digital_entity (
  digital_entity_id,
  digital_entity_type,
  access_uri,
  web_statement,
  format,
  license,
  rights,
  rights_uri,
  access_rights,
  rights_holder,
  source,
  source_uri,
  creator,
  created,
  modified,
  language,
  bibliographic_citation
)  ( select
     concat('https://arctos.database.museum/media/',media.media_id),
       -- ugh, how the heck am I supposed to know?
      case
        when media.media_type in ('image') then 'STILL_IMAGE'
        when media.media_type in ('audio') then 'SOUND'
        when media.media_type in ('video') then 'MOVING_IMAGE'
        else 'TEXT'
    end,
    --https://github.com/ArctosDB/internal/issues/240; this might get better
    concat('https://arctos.database.museum/media/',media.media_id),
    null, --web_statement
    null, --format
    ctmedia_license.uri,
    null, --rights
    null, --rights_uri
    null, --access_rights
    null, --rights_holder
    null, --source
    null, --source_uri
    null, --creator
    null, --created
    null, --modified
    null, --language
    null
from media
left outer join ctmedia_license on media.media_license_id=ctmedia_license.media_license_id
);


-- records to parts
-- https://github.com/gbif/model-material/issues/114

insert into gum.entity_relationship (
  entity_relationship_id,
  depends_on_entity_relationship_id,
  subject_entity_id,
  entity_relationship_type,
  object_entity_id,
  object_entity_iri,
  entity_relationship_date,
  entity_relationship_order
) (
select
    nextval('somerandomsequence')::text, -- do I need this?? Hope not...
    null, -- hu?
    gum_ent_cat_rec.entity_id as subject_entity_id, --subject_entity_id
    --https://github.com/gbif/model-material/issues/119
    'MATERIAL SAMPLE OF', -- ??
    gum_ent_part.entity_id as object_entity_id, --object_entity_id
    null,
    null,
    1 -- wth is this?!
from
 gum.entity gum_ent_cat_rec
 inner join gum.entity gum_ent_part on gum_ent_part.arctos_CID=gum_ent_cat_rec.arctos_CID and gum_ent_part.arctos_PID is not null
 where
 gum_ent_cat_rec.arctos_PID is null and gum_ent_cat_rec.arctos_MID is null
);


-- records to media
-- is there a place for more media relationships? Surely having them in two places isn't by design?
-- https://github.com/gbif/model-material/issues/115
--subject_entity_id


-- https://github.com/gbif/model-material/issues/111

--select subject_entity_id,object_entity_id from gum.entity_relationship;



insert into gum.entity_relationship (
  entity_relationship_id,
  depends_on_entity_relationship_id,
  subject_entity_id,
  entity_relationship_type,
  object_entity_id,
  object_entity_iri,
  entity_relationship_date,
  entity_relationship_order
) (select
    nextval('somerandomsequence')::text, -- do I need this?? Hope not...
    null, -- hu?
    gum_ent_cat_rec.entity_id as subject_entity_id,--subject_entity_id
    --https://github.com/gbif/model-material/issues/115#issuecomment-1477884833
    case
        when media.media_type='image' then 'IMAGE OF'
        else concat('has ',media.media_type)
    end,
    gum_ent_media_records.entity_id as object_entity_id, --object_entity_id
    null,
    null,
    1 -- wth is this?!
from
 gum.entity gum_ent_cat_rec
 inner join media_relations on gum_ent_cat_rec.arctos_CID=media_relations.cataloged_item_id
 inner join gum.entity gum_ent_media_records on media_relations.media_id=gum_ent_media_records.arctos_MID
 inner join media on media_relations.media_id=media.media_id
 where
 gum_ent_cat_rec.arctos_CID is not null and
 gum_ent_cat_rec.arctos_PID is null and
 gum_ent_cat_rec.arctos_MID is null and
 gum_ent_media_records.arctos_MID is not null and
 gum_ent_media_records.arctos_PID is null
);















----------- JRW: Add records to genbank
--- this is a formal mapping to entities that are not in arctos but are connected
-- use object_entity_iri http.....

-- entity relationship type==has sequence
-- also consider using this for parasites and other "separate" things
-- IDK what that is, its a very blurry line, suspect most don't have extra data??


-- delete from gum.entity_relationship where entity_relationship_type='has sequence';
--https://github.com/gbif/model-material/issues/116
insert into gum.entity_relationship (
  entity_relationship_id,
  depends_on_entity_relationship_id,
  subject_entity_id,
  entity_relationship_type,
  object_entity_id,
  object_entity_iri,
  entity_relationship_date,
  entity_relationship_order
) (select
    nextval('somerandomsequence')::text, -- do I need this?? Hope not...
    null, -- hu?
    gum.entity.entity_id,
    'has genetic sequence',
    null, --object_entity_id null because remote
    link_value, --object_entity_iri
    null,
    1 -- wth is this?!
from
 gum.entity
 inner join coll_obj_other_id_num on gum.entity.arctos_CID=coll_obj_other_id_num.collection_object_id
 where
 coll_obj_other_id_num.other_id_type='GenBank'
 -- way too many rows without this! (Copypastaed elsewhere, hopefully without borkage)
 and  gum.entity.arctos_pid is null and gum.entity.arctos_mid is null
);



----------- place
-- thigns get ripped apart and put back together, I need a local ID I guess
-- shuffle this for partial exports - first build specimen_event equivilants


--- these events are parent of 'Occurrences'====specimen_events
-- join to gum.entity to get GUIDs, and to honor mask record records (and to filter)
-- include arctos_eid (event_id==collecting_event_id) for future filters
-- EXCLUDE masked localities

insert into gum.event (
  event_id,
  parent_event_id,
  dataset_id,
  location_id,
  protocol_id,
  event_type,
  event_name ,
  field_number,
  event_date,
  year,
  month,
  day,
  verbatim_event_date,
  verbatim_locality,
  verbatim_elevation,
  verbatim_depth,
  verbatim_coordinates,
  verbatim_latitude,
  verbatim_longitude,
  verbatim_coordinate_system,
  verbatim_srs,
  habitat,
  protocol_description,
  sample_size_value,
  sample_size_unit,
  event_effort,
  field_notes,
  event_remarks,
  arctos_eid,
  arctos_seid
) ( select
  -- the OccurrenceID, ephemeral as it may be, that we've been throwing around forever
    concat(gum.entity.entity_id,'?seid=',specimen_event.specimen_event_id),
    concat('https://arctos.database.museum/place.cfm?action=detail&collecting_event_id=',specimen_event.collecting_event_id),
     'Arctos', -- not a clue but can't be null....
     -- dataset ID is for aggregation
     -- grscicol??????????
     -- re conversation with JRW we are declaring Arctos to be a dataset
     -- eventually: issue this
    null, --location_id: doesn't seem appropriate here, this is going to an event which has that
    null, -- protocol_id
    specimen_event.specimen_event_type, --event_type
    null, -- event_name - these don't have names, parents might
    null, -- field_number?
    null, -- event_date: might use assigned or verified dates here but I don't think that makes sense
    null, -- year
    null, --month
    null, --day
    null, --verbatim_event_date
    null, --verbatim_locality
    null, --verbatim_elevation
    null, --verbatim_depth
    null, --verbatim_coordinates
    null, --verbatim_latitude
    null, --verbatim_longitude
    null, --verbatim_coordinate_system
    null, --verbatim_srs
    specimen_event.habitat, --habitat
    concat_ws('|','collecting_method: ' ||specimen_event.collecting_method, 'collecting_source: ' ||specimen_event.collecting_source), --protocol_description
    null, --sample_size_value
    null, --sample_size_unit
    null, --event_effort
    null, --field_notes
    specimen_event.specimen_event_remark,
    specimen_event.collecting_event_id,
    specimen_event.specimen_event_id
from
  gum.entity
  inner join specimen_event on gum.entity.arctos_CID=specimen_event.collection_object_id
  inner join collecting_event on specimen_event.collecting_event_id=collecting_event.collecting_event_id
  --- lets just don't make these for records with encumbered event-stuff
  -- this might be adjusted to include some information later, but not yet
  inner join cataloged_item on specimen_event.collection_object_id=cataloged_item.collection_object_id
  left outer join (
    select coll_object_encumbrance.collection_object_id,coll_object_encumbrance.encumbrance_id from coll_object_encumbrance
    inner join encumbrance on coll_object_encumbrance.encumbrance_id=encumbrance.encumbrance_id
    where encumbrance.encumbrance_action in ('mask coordinates','mask year collected')
  ) atrencs on cataloged_item.collection_object_id=atrencs.collection_object_id
   left outer join (
      select locality_id from locality_attributes
        where  attribute_type='locality access'
      ) latar on collecting_event.locality_id=latar.locality_id
where atrencs.collection_object_id is null
and gum.entity.arctos_PID is null and gum.entity.arctos_mid is null and
latar.locality_id is null
);




---these events represent collecting events
-- join to previous to filter for only what's necessary
-- and to honor restricted locality access


insert into gum.event (
  event_id,
 -- parent_event_id,
  dataset_id,
  location_id,
  --protocol_id,
  event_type,
  event_name ,
  --field_number,
  event_date,
  --year,
  --month,
  --day,
  verbatim_event_date,
  verbatim_locality,
 -- verbatim_elevation,
 -- verbatim_depth,
  verbatim_coordinates,
 -- verbatim_latitude,
  --verbatim_longitude,
  --verbatim_coordinate_system,
 -- verbatim_srs,
 -- habitat,
--  protocol_description,
--  sample_size_value,
--  sample_size_unit,
--  event_effort,
 -- field_notes,
  event_remarks,
  arctos_EID
) ( select distinct
    concat('https://arctos.database.museum/place.cfm?action=detail&collecting_event_id=',collecting_event.collecting_event_id),
   -- null, --parent_event_id
     'Arctos', -- not a clue but can't be null....
     -- dataset ID is for aggregation
     -- grscicol??????????
     -- re conversation with JRW we are declaring Arctos to be a dataset
     -- eventually: issue this
    concat('https://arctos.database.museum/place.cfm?action=detail&locality_id=',collecting_event.locality_id),
    --null, -- protocol_id: wut?
    'eventing event', -- event type can't be NULL and I have no idea what this is
    collecting_event.collecting_event_name,
   -- null, --field_number wutwutwut?
    collecting_event.verbatim_date,
   -- null,
    --null,
    --null,
    collecting_event.verbatim_date, -- hu??
    collecting_event.verbatim_locality,
   -- null, --verbatim_elevation
   -- null, --verbatim_depth
    collecting_event.verbatim_coordinates, --verbatim_coordinates
   -- null, --verbatim_latitude
   -- null, --verbatim_longitude
   -- null, --verbatim_coordinate_system
    --null, --verbatim_srs
  --  null, --habitat
  --  null, --protocol_description
  --  null, --sample_size_value
   -- null, --sample_size_unit
    --null, --event_effort
   -- null, --field_notes
    collecting_event.coll_event_remarks,
    collecting_event.collecting_event_id
from
    collecting_event
    inner join gum.event seideq on collecting_event.collecting_event_id=seideq.arctos_EID
);



--select event_id from gum.event group by event_id having count(*) > 1;


-- now locality, joined to above
-- and double-filtered because belt and suspenders
-- delete from  gum.location
insert into gum.location (
  location_id,
 -- parent_location_id,
  higher_geography_id,
  higher_geography,
  continent,
  --water_body,
  island_group,
  island,
  country,
  --country_code,
  state_province,
  county,
  --municipality,
  locality,
  minimum_elevation_in_meters,
  maximum_elevation_in_meters,
  --minimum_distance_above_surface_in_meters,
  --maximum_distance_above_surface_in_meters,
  minimum_depth_in_meters,
  maximum_depth_in_meters,
  --vertical_datum,
  --location_according_to,
  location_remarks,
  accepted_georeference_id,
 -- accepted_geological_context_id,
  arctos_LID
) ( select distinct
    concat('https://arctos.database.museum/place.cfm?action=detail&locality_id=',locality.locality_id),
    --null parent_location_id,
    concat('https://arctos.database.museum/place.cfm?action=detail&geog_auth_rec_id=',geog_auth_rec.geog_auth_rec_id),
    geog_auth_rec.higher_geog,
    geog_auth_rec.continent_ocean,
    --null water_body,
    geog_auth_rec.island_group,
    geog_auth_rec.island,
    geog_auth_rec.country,
    --null country_code,
    geog_auth_rec.state_prov,
    geog_auth_rec.county,
    --null municipality,
    locality.spec_locality,
    to_meters(locality.minimum_elevation,locality.orig_elev_units),
    to_meters(locality.maximum_elevation,locality.orig_elev_units),
    --null minimum_distance_above_surface_in_meters,
    --null maximum_distance_above_surface_in_meters,
    to_meters(locality.min_depth,locality.depth_units),
    to_meters(locality.max_depth,locality.depth_units),
    --null, vertical_datum
    --null, location_according_to -- wut?
    locality.locality_remarks,
    -- accepted_georeference_id -- https://github.com/gbif/model-material/issues/107
    -- have to filter or we make orphans ARGH!
    case when locality.dec_lat is null then null else concat('https://arctos.database.museum/place.cfm?action=detail&locality_id=',locality.locality_id) end,
    locality.locality_id
    from locality
    inner join geog_auth_rec on locality.geog_auth_rec_id=geog_auth_rec.geog_auth_rec_id
    inner join collecting_event on locality.locality_id=collecting_event.locality_id
    inner join gum.event seideq on collecting_event.collecting_event_id=seideq.arctos_EID
    left outer join (
      select locality_id from locality_attributes
        where  attribute_type='locality access'
      ) latar on locality.locality_id=latar.locality_id
    where
    latar.locality_id is null and
    -- https://github.com/ArctosDB/arctos/issues/5590
    coalesce(to_meters(locality.maximum_elevation,locality.orig_elev_units),0) between-430 AND 8850
);

--select location_id from gum.location group by location_id having count(*) > 1;

-- honor encumbrances by joining to gum.location
insert into gum.georeference (
  georeference_id,
  location_id,
  decimal_latitude,
  decimal_longitude,
  geodetic_datum,
  coordinate_uncertainty_in_meters,
  coordinate_precision,
  point_radius_spatial_fit,
  footprint_wkt,
  footprint_srs,
  footprint_spatial_fit,
  georeferenced_by,
  georeferenced_date,
  georeference_protocol,
  georeference_sources,
  georeference_remarks,
  preferred_spatial_representation
) (select
    gum.location.location_id,
    gum.location.location_id,
    locality.dec_lat,
    locality.dec_long,
    locality.datum,
    to_meters(locality.max_error_distance,locality.max_error_units),
    null,
    null,
    ST_AsText(locality.locality_footprint),
    null,
    null,
    null, --georeferenced_by might be extraced from the locality attribute but it's not 1:1 so doesn't really fit
    null,
    null,
    null,
    null,
    locality.primary_spatial_data
from
    locality
    inner join gum.location on locality.locality_id=gum.location.arctos_LID
where locality.dec_lat is not null
);




-- I have basically no idea how to approach this so just gonna ignore almost all of it...
--delete from gum.geological_context;
insert into gum.geological_context (
  geological_context_id,
  location_id,
  earliest_eon_or_lowest_eonothem ,
  latest_eon_or_highest_eonothem,
  earliest_era_or_lowest_erathem,
  latest_era_or_highest_erathem,
  earliest_period_or_lowest_system,
  latest_period_or_highest_system,
  earliest_epoch_or_lowest_series,
  latest_epoch_or_highest_series,
  earliest_age_or_lowest_stage,
  latest_age_or_highest_stage,
  lowest_biostratigraphic_zone,
  highest_biostratigraphic_zone,
  lithostratigraphic_terms,
  "group",
  formation,
  member ,
  bed
) (select
    nextval('somerandomsequence')::text,
    concat('https://arctos.database.museum/place.cfm?action=detail&locality_id=',locality_attributes.locality_id),
    null, --earliest_eon_or_lowest_eonothem
    null, --latest_eon_or_highest_eonothem
    null, --earliest_era_or_lowest_erathem
    null, --latest_era_or_highest_erathem
    null, --earliest_period_or_lowest_system
    null, --latest_period_or_highest_system
    null, --earliest_epoch_or_lowest_series
    null, --latest_epoch_or_highest_series
    null, --earliest_age_or_lowest_stage
    null, --latest_age_or_highest_stage
    null, --lowest_biostratigraphic_zone
    null, --highest_biostratigraphic_zone
    null, --lithostratigraphic_terms
    concatLocalityAttributeValue(locality_attributes.locality_id,'lithostratigraphic group'),
    concatLocalityAttributeValue(locality_attributes.locality_id,'lithostratigraphic formation'),
    concatLocalityAttributeValue(locality_attributes.locality_id,'lithostratigraphic member'),
    concatLocalityAttributeValue(locality_attributes.locality_id,'lithostratigraphic bed')
from
    gum.location -- this protects locality attribute access
    inner join locality_attributes on gum.location.arctos_LID=locality_attributes.locality_id
where  locality_attributes.attribute_type in
    (
        'lithostratigraphic group',
        'lithostratigraphic formation',
        'lithostratigraphic member',
        'lithostratigraphic bed'
    )
);




insert into gum.identification (
  identification_id,
  organism_id, -- foreign key declared after organism table
  identification_type,
  taxon_formula,
  verbatim_identification,
  type_status,
  identified_by,
  identified_by_id,
  date_identified,
  identification_references,
  identification_verification_status,
  identification_remarks,
  type_designation_type,
  type_designated_by,
  arctos_IID
) (select distinct
     concat('https://arctos.database.museum/guid/',guid_prefix,':',cat_num,'/IID',identification.identification_id),
     concat('https://arctos.database.museum/guid/',guid_prefix,':',cat_num),
    nature_of_id,
    taxa_formula,
    scientific_name,
    null, -- type_status -  wut??
    null, -- identified_by - not cramming agents in this thing....
    null, --identified_by_id ??
    made_date,
    concat('https://arctos.database.museum/publication/',identification.publication_id::text), --??????????????????
    identification_confidence,
    identification_remarks,
    null,
    null,
    identification.identification_id
from
    identification
    inner join cataloged_item on identification.collection_object_id=cataloged_item.collection_object_id
    inner join collection on cataloged_item.collection_id=collection.collection_id
    -- avoid mask record encumbrances
    inner join gum.entity on cataloged_item.collection_object_id=gum.entity.arctos_CID
  where gum.entity.arctos_PID is null and gum.entity.arctos_mid is null
);





-- I have no idea what this is supposed to do but I guess i can't make Occurrences without it??
-- I'm about to declare a bus an organism
-- I feel dirty
-- https://github.com/gbif/model-material/issues/112
insert into gum.organism (
  organism_id,
  organism_scope,
  accepted_identification_id
)(select
gum.entity.entity_id,
NULL, --'catalog record', -- IDK...
 concat(
  gum.entity.entity_id,
  '/IID',
  -- get  something hopefully-not-quite-random to fit in the overly-constrictive structure
  (select identification_id from identification where identification.collection_object_id=gum.entity.arctos_CID order by accepted_id_fg desc limit 1)
)
 from
 gum.entity
 where arctos_CID is not null and arctos_PID is null and arctos_MID is null
);



















insert into gum.occurrence (
  occurrence_id,
  organism_id,
  organism_quantity,
  organism_quantity_type,
  sex,
  life_stage,
  reproductive_condition,
  behavior,
  establishment_means,
  occurrence_status,
  pathway,
  degree_of_establishment,
  georeference_verification_status,
  occurrence_remarks,
  information_withheld,
  data_generalizations,
  recorded_by,
  recorded_by_id,
  associated_media,
  associated_occurrences,
  associated_taxa
) ( select
    gum.event.event_id,
    substring(gum.event.event_id,1,position('?' in gum.event.event_id)-1),
    null,--organism_quantity
    null,--organism_quantity_type
    null,--sex
    null,--life_stage
    null,--reproductive_condition
    null,--behavior
    null,--establishment_means
    'PRESENT',--occurrence_status
    null, --pathway
    null, --degree_of_establishment
    verificationstatus, --georeference_verification_status
    null, --occurrence_remarks
    null, --information_withheld
    null, --data_generalizations
    null, --recorded_by
    null, --recorded_by_id
    null, --associated_media
    null, --associated_occurrences
    null --associated_taxa
    from
    gum.event
    inner join specimen_event on gum.event.arctos_seid=specimen_event.specimen_event_id
    where
    arctos_seid is not null
);











-- no idea what to do with this
-- the structure makes all sorts of assumptions that we can't support
-- doing basically nothing I guess???
-- hierarchical != 'normalized'!!!!!!
-- JWR conversation: share "compiled taxonomy" from flat, file an issue and do something better later
-- after more thought: not sure that'll work - names certainly cannot be unique within that, there may be
-- 300 ideas (one for each collection) of what [some rank] means WRT [some name]

/*
-- omg wtf
-- https://github.com/ArctosDB/arctos/issues/5670
-- we need an Arctos Exorcist
-- I can bring candles
delete from taxon_term where taxon_name_id=12121987;
delete from taxon_name where taxon_name_id=12121987;
delete from taxon_term where taxon_name_id=12121999;
delete from taxon_name where taxon_name_id=12121999;


select taxon_name_id,scientific_name,getPreferredAgentName(created_by_agent_id),created_date  from taxon_name where scientific_name ilike 'Viola pr%' order by scientific_name;

*/



insert into gum.taxon (
  taxon_id,
  scientific_name,
  scientific_name_authorship,
  name_according_to,
  name_according_to_id,
  taxon_rank,
  taxon_source,
  scientific_name_id,
  taxon_remarks,
  parent_taxon_id,
  taxonomic_status,
  kingdom,
  phylum,
  class,
  "order",
  family,
  subfamily,
  genus,
  subgenus,
  accepted_scientific_name
) (
  select
       concat('https://arctos.database.museum/name/',taxon_name.scientific_name),
       taxon_name.scientific_name,
       null, --scientific_name_authorship is classification data - homonyms allow nothing else
       null, -- name_according_to=classification
       null, --name_according_to_id
       null, --taxon_rank
       null, --taxon_source
       null, --scientific_name_id
       null, --taxon_remarks
       null, --parent_taxon_id
       null, --taxonomic_status,
       null, -- kingdom
       null, -- phylum
       null, -- class
       null, -- order
       null, -- family
       null, -- subfamily
       null, -- genus
       null, -- subgenus
       null --accepted_scientific_name, -- accepted_scientific_name - what about when there are hundreds of synonyms and we don't have a binary view of acceptedness????
      from taxon_name
);


--delete from gum.taxon_identification;

insert into gum.taxon_identification (
taxon_id,
identification_id,
taxon_order,
taxon_authority
)(
select
    concat('https://arctos.database.museum/name/',taxon_name.scientific_name),
     gum.identification.identification_id,
     case when identification_taxonomy.variable='A' then 1 else 2 end,
     null -- taxon_authority - wutwut?
  from
    core.identification
    inner join core.identification_taxonomy on core.identification.identification_id=core.identification_taxonomy.identification_id
    inner join core.taxon_name on core.identification_taxonomy.taxon_name_id=core.taxon_name.taxon_name_id
    -- avoid encumbrances by joining to gum.identifications which already avoids encumbrances
    -- normal:
    inner join gum.identification on core.identification.identification_id=gum.identification.arctos_IID
    -- after the purge
    --inner join gum.identification on core.identification.identification_id=replace(SPLIT_PART(gum.identification.identification_id,'/',6),'IID','')::int
);

--select identification_id,replace(SPLIT_PART(identification_id,'/',6),'IID','')::int from  gum.identification limit 1;

-- join to gum.entity to avoid record encumbrances
-- just avoid everything to avoid attribute-level encumbrances; this could be refined but that would need a
-- lot more attention than I feel I have to offer at the moment


insert into gum."assertion" (
  assertion_id,
  assertion_target_id,
  assertion_target_type,
  assertion_parent_assertion_id,
  assertion_type,
  assertion_made_date,
  assertion_effective_date,
  assertion_value,
  assertion_value_numeric,
  assertion_unit,
  assertion_by_agent_name,
  assertion_by_agent_id,
  assertion_protocol,
  assertion_protocol_id,
  assertion_remarks
)(
select distinct
  -- this didn't work for some reason but I can't see how I'm making dups so??? attributes.attribute_id::text,
   nextval('somerandomsequence')::text,
  gum.entity.entity_id,
  'ENTITY',
  null, --assertion_parent_assertion_id
  attributes.attribute_type,
  attributes.determined_date,
  null, --assertion_effective_date
  attributes.attribute_value,
  case when attributes.attribute_units is null then null else attributes.attribute_value::numeric end, -- why is this on my end??
  attributes.attribute_units,
  null, --assertion_by_agent_name
  'https://arctos.database.museum/agent/' || attributes.determined_by_agent_id,
  null,
  null,
  attributes.attribute_remark
from
attributes
inner join gum.entity on attributes.collection_object_id=gum.entity.arctos_CID
left outer join (
  select coll_object_encumbrance.collection_object_id,coll_object_encumbrance.encumbrance_id from coll_object_encumbrance
  inner join encumbrance on coll_object_encumbrance.encumbrance_id=encumbrance.encumbrance_id
  where encumbrance.encumbrance_action in ('mask value','mask unformatted measurements','mask NAGPRA category')
) atrencs on attributes.collection_object_id=atrencs.collection_object_id
where atrencs.collection_object_id is null
and gum.entity.arctos_PID is null and gum.entity.arctos_mid is null
);



-- my long-lost part attributes!!
  -- https://github.com/ArctosDB/arctos/issues/5696, these data have some issues, below can be cleaned up when that issue is done
  --case when specimen_part_attribute.attribute_units is null then null else specimen_part_attribute.attribute_value::numeric end, -- why is this on my end??


insert into gum."assertion" (
  assertion_id,
  assertion_target_id,
  assertion_target_type,
  assertion_parent_assertion_id,
  assertion_type,
  assertion_made_date,
  assertion_effective_date,
  assertion_value,
  --assertion_value_numeric,
  assertion_unit,
  assertion_by_agent_name,
  assertion_by_agent_id,
  assertion_protocol,
  assertion_protocol_id,
  assertion_remarks
)(
select distinct
  nextval('somerandomsequence')::text, --assertion_id
  gum.entity.entity_id, --assertion_target_id
  'MATERIAL_ENTITY', --assertion_target_type
  null, --assertion_parent_assertion_id
  specimen_part_attribute.attribute_type, --assertion_type
  specimen_part_attribute.determined_date, --assertion_made_date
  null, --assertion_effective_date
  specimen_part_attribute.attribute_value, --assertion_value
  --null, --assertion_value_numeric
  specimen_part_attribute.attribute_units, --assertion_unit
  null, --assertion_by_agent_name
  'https://arctos.database.museum/agent/' || specimen_part_attribute.determined_by_agent_id, --assertion_by_agent_id
  null, --assertion_protocol
  null, --assertion_protocol_id
  specimen_part_attribute.attribute_remark --assertion_remarks
from
specimen_part_attribute
inner join gum.entity on specimen_part_attribute.collection_object_id=gum.entity.arctos_PID
inner join specimen_part on specimen_part_attribute.collection_object_id=specimen_part.collection_object_id
left outer join (
  select coll_object_encumbrance.collection_object_id,coll_object_encumbrance.encumbrance_id from coll_object_encumbrance
  inner join encumbrance on coll_object_encumbrance.encumbrance_id=encumbrance.encumbrance_id
  where encumbrance.encumbrance_action in ('mask part attribute location')
) atrencs on specimen_part.derived_from_cat_item=atrencs.collection_object_id
where atrencs.collection_object_id is null
);



-- locality attributes
-- joining to gum.location protects encumbrances
insert into gum."assertion" (
  assertion_id,
  assertion_target_id,
  assertion_target_type,
  assertion_parent_assertion_id,
  assertion_type,
  assertion_made_date,
  assertion_effective_date,
  assertion_value,
  assertion_value_numeric,
  assertion_unit,
  assertion_by_agent_name,
  assertion_by_agent_id,
  assertion_protocol,
  assertion_protocol_id,
  assertion_remarks
)(
select distinct
  nextval('somerandomsequence')::text,
  gum.location.location_id,
  'LOCATION',
  null, --assertion_parent_assertion_id
  locality_attributes.attribute_type,
  locality_attributes.determined_date,
  null, --assertion_effective_date
  locality_attributes.attribute_value,
  case when locality_attributes.attribute_units is null then null else locality_attributes.attribute_value::numeric end, -- why is this on my end??
  locality_attributes.attribute_units,
  null, --assertion_by_agent_name
  'https://arctos.database.museum/agent/' || locality_attributes.determined_by_agent_id,
  null,
  null,
  locality_attributes.attribute_remark
from
locality_attributes
inner join gum.location on locality_attributes.locality_id=gum.location.arctos_LID
);







-- event attributes
-- joining to gum.event protects encumbrances
-- but I wish it had an arctos id - rebuild this to use it after rebuilding to include, added above

insert into gum."assertion" (
  assertion_id,
  assertion_target_id,
  assertion_target_type,
  assertion_parent_assertion_id,
  assertion_type,
  assertion_made_date,
  assertion_effective_date,
  assertion_value,
 -- assertion_value_numeric,
  assertion_unit,
  assertion_by_agent_name,
  assertion_by_agent_id,
  assertion_protocol,
  assertion_protocol_id,
  assertion_remarks
)(
select distinct
  nextval('somerandomsequence')::text, --assertion_id
  gum.event.event_id, --assertion_target_id
  'EVENT',
  null, --assertion_parent_assertion_id
  collecting_event_attributes.event_attribute_type,
  collecting_event_attributes.event_determined_date,
  null, --assertion_effective_date
  collecting_event_attributes.event_attribute_value,
  -- wth null is text??? null, -- assertion_value_numeric; why is this on my end??
  collecting_event_attributes.event_attribute_units,
  null, --assertion_by_agent_name
  'https://arctos.database.museum/agent/' || collecting_event_attributes.determined_by_agent_id,
  null,
  null,
  collecting_event_attributes.event_attribute_remark
from
collecting_event_attributes
inner join gum.event on collecting_event_attributes.collecting_event_id=gum.event.arctos_EID
);



--delete from gum.identifier;
-- joining to gum.entity prevents mask record encumbrance leaks
insert into gum.identifier (
  identifier_target_id,
  identifier_target_type,
  identifier_type,
  identifier_value
) (
select distinct
gum.entity.entity_id,
'ENTITY',
coll_obj_other_id_num.other_id_type,
case when coll_obj_other_id_num.link_value is not null then coll_obj_other_id_num.link_value else coll_obj_other_id_num.display_value end
from
coll_obj_other_id_num
inner join  gum.entity on coll_obj_other_id_num.collection_object_id=gum.entity.arctos_CID
left outer join (
    select coll_object_encumbrance.collection_object_id,encumbrance.encumbrance_id
    from encumbrance inner join coll_object_encumbrance on coll_object_encumbrance.encumbrance_id=encumbrance.encumbrance_id and
    encumbrance_action='mask original field number'
) mre on coll_obj_other_id_num.collection_object_id=mre.collection_object_id
where mre.encumbrance_id is null
and gum.entity.arctos_PID is null and gum.entity.arctos_mid is null
);


-- and select agent addresses
-- dammit need id - lets go backwards then
-- more unreasonable constraints!! - add a distinct to dump some data

insert into gum.identifier (
  identifier_target_id,
  identifier_target_type,
  identifier_type,
  identifier_value
) (
select distinct
 concat('https://arctos.database.museum/agent/',agent_id::text),
'AGENT',
address_type,
address
from
address where address_type in (
  'collectionID',
  'Wikidata',
  'url',
  'ORCID',
  'Library of Congress'
)
);


-- all nonpreferred agent names here
-- i think WHEEEEE!!!

insert into gum.identifier (
  identifier_target_id,
  identifier_target_type,
  identifier_type,
  identifier_value
) (
select distinct
 concat('https://arctos.database.museum/agent/',agent_id::text),
'AGENT',
agent_name_type,
agent_name
from
agent_name
);




-- collectors
--https://github.com/gbif/model-material/issues/106
-- agent_role_target_id is apparently supposed to be the entity
--https://github.com/gbif/model-material/issues/120

insert into gum.agent_role (
  agent_role_target_id,
  agent_role_target_type,
  agent_role_agent_id,
  agent_role_agent_name,
  agent_role_role,
  agent_role_began,
  agent_role_ended,
  agent_role_order
)(
select
    gum.entity.entity_id,
  'ENTITY', --agent_role_target_type
  concat('https://arctos.database.museum/agent/',agent_id::text), --agent_role_agent_id
  null, -- agent_role_agent_name - what is this??
  collector.collector_role, -- agent_role_role
  null,
  null,
  collector.coll_order
  from
  collector
  --- avoid mask record
  inner join gum.entity on collector.collection_object_id= gum.entity.arctos_CID
  left outer join (
    select coll_object_encumbrance.collection_object_id,encumbrance.encumbrance_id
    from encumbrance inner join coll_object_encumbrance on coll_object_encumbrance.encumbrance_id=encumbrance.encumbrance_id and
    encumbrance_action in ('mask collector','mask preparator')
) mre on collector.collection_object_id=mre.collection_object_id
where mre.encumbrance_id is null
and gum.entity.arctos_PID is null and gum.entity.arctos_mid is null
);



------------ citations now that we have all the bits
---- not linked to identifications but we can fake that
insert into gum.citation(
  citation_target_id,
  citation_target_type,
  citation_reference_id,
  citation_type,
  citation_page_number,
  citation_remarks
) (select
   gum.entity.entity_id,
   'ORGANISM', -- IDK....
   concat('https://arctos.database.museum/publication/',publication_id::text),
   type_status,
   occurs_page_number,
   citation_remarks
from
citation
inner join gum.entity on citation.collection_object_id=gum.entity.arctos_CID
where gum.entity.arctos_PID is null and gum.entity.arctos_MID is null
);



----------- done here



--- strip my extra columns out
alter table gum.entity drop column arctos_CID;
alter table gum.entity drop column arctos_PID;
alter table gum.entity drop column arctos_MID;
alter table gum.location drop column arctos_LID;
alter table gum.event drop column arctos_EID;
alter table gum.identification drop column arctos_IID;
alter table gum.identification drop column arctos_AIID;
alter table gum.event drop column arctos_SEID;






 \copy gum.collection to 'collection.csv' csv header;
 \copy gum.agent_group to 'agent_group.csv' csv header;
 \copy gum.agent_relationship to 'agent_relationship.csv' csv header;
 \copy gum.agent to 'agent.csv' csv header;
 \copy gum.collection to 'collection.csv' csv header;
 \copy gum.agent_group to 'agent_group.csv' csv header;
 \copy gum.agent_relationship to 'agent_relationship.csv' csv header;
 \copy gum.reference to 'reference.csv' csv header;
 \copy gum.digital_entity to 'digital_entity.csv' csv header;
 \copy gum.entity_relationship to 'entity_relationship.csv' csv header;
 \copy gum.occurrence to 'occurrence.csv' csv header;
 \copy gum.organism to 'organism.csv' csv header;
 \copy gum.taxon_identification to 'taxon_identification.csv' csv header;
 \copy gum.taxon to 'taxon.csv' csv header;
 \copy gum.identification to 'identification.csv' csv header;
 \copy gum.chronometric_age to 'chronometric_age.csv' csv header;
 \copy gum."assertion" to 'assertion.csv' csv header;
 \copy gum.identifier to 'identifier.csv' csv header;
 \copy gum.agent_role to 'agent_role.csv' csv header;
 \copy gum.event to 'event.csv' csv header;
 \copy gum.material_entity to 'material_entity.csv' csv header;
 \copy gum.entity to 'entity.csv' csv header;
 \copy gum.protocol to 'protocol.csv' csv header;
 \copy gum.georeference to 'georeference.csv' csv header;
 \copy gum.geological_context to 'geological_context.csv' csv header;
 \copy gum.location to 'location.csv' csv header;



